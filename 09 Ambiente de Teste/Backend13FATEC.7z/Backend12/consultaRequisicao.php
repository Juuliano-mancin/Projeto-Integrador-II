<?php
// Iniciando a sessão
session_start();

// Verificando se o usuário está logado
if (!isset($_SESSION['nome']) || !isset($_SESSION['sobrenome'])) {
    // Se o usuário não estiver logado, redireciona para a página de login
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=justificativafaltas', 'root', 'fatec');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erro ao conectar ao banco de dados: " . $e->getMessage();
    exit();
}

// Obtendo o ID da requisição via GET
$idRequisicao = isset($_GET['idrequisicao']) ? intval($_GET['idrequisicao']) : 0;

// Consultar a requisição no banco de dados
$sql = "SELECT r.idrequisicao, c.siglacurso AS curso, cf.categoria, 
               DATE_FORMAT(r.data_inicial, '%d %m %Y') AS data_inicial,
               DATE_FORMAT(r.data_final, '%d %m %Y') AS data_final,
               r.comentarioprofessor, r.statusrequisicao, r.comentariocoordenacao
        FROM tb_requisicao_faltas r
        JOIN tb_cursos c ON r.idcurso = c.idcurso
        JOIN tb_categoria_faltas cf ON r.idcategoria = cf.idcategoria
        WHERE r.idrequisicao = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$idRequisicao]);
$linha = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$linha) {
    echo "Requisição não encontrada.";
    exit();
}

// Consultar as reposições associadas à requisição, pegando todos os campos de tb_reposicao_aulas
$sqlReposicao = "SELECT r.datareposicao, c.curso, d.disciplina, r.numeroaulas, 
               r.horainicioreposicao, r.horafinalreposicao, r.tiporeposicao, 
               r.statusreposicao, r.comentariocoordenacao
        FROM tb_reposicao_aulas r
        JOIN tb_disciplinas d ON r.iddisciplina = d.iddisciplina
        JOIN tb_cursos c ON r.idcurso = c.idcurso
        WHERE r.idrequisicao = :idrequisicao";
$stmtReposicao = $pdo->prepare($sqlReposicao);
$stmtReposicao->execute(['idrequisicao' => $idRequisicao]);
$reposicoes = $stmtReposicao->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Requisição</title>
    <link rel="stylesheet" href="consultaRequisicao.css">
</head>
<body>
    <header>
        <form action="logout.php" method="POST" style="float: right; margin: 10px;">
            <button type="submit">Logout</button>
        </form>
        <h1>Consulta de Requisição</h1>
    </header>

    <div class="principal">
        <h2>Detalhes da Requisição</h2>
        <form>
            <label>ID da Requisição:</label>
            <input type="text" value="<?php echo htmlspecialchars($linha['idrequisicao']); ?>" disabled>

            <label>Sigla do Curso:</label>
            <input type="text" value="<?php echo htmlspecialchars($linha['curso']); ?>" disabled>

            <label>Categoria:</label>
            <input type="text" value="<?php echo htmlspecialchars($linha['categoria']); ?>" disabled>

            <label>Data Inicial:</label>
            <input type="text" value="<?php echo htmlspecialchars($linha['data_inicial']); ?>" disabled>

            <label>Data Final:</label>
            <input type="text" value="<?php echo htmlspecialchars($linha['data_final']); ?>" disabled>

            <label>Comentário do Professor:</label>
            <textarea disabled><?php echo htmlspecialchars($linha['comentarioprofessor']); ?></textarea>

            <label>Status:</label>
            <input type="text" value="<?php echo htmlspecialchars($linha['statusrequisicao']); ?>" disabled>

            <label>Comentário da Coordenação:</label>
            <textarea disabled><?php echo htmlspecialchars($linha['comentariocoordenacao']); ?></textarea>
        </form>

        <!-- Exibição das reposições -->
        <h1>Consulta de Reposições</h1>
        <?php
        // Se existirem reposições, elas serão exibidas aqui
        if (count($reposicoes) > 0) {
            echo "<table border='1'>";
            echo "<thead><tr>";

            // Cabeçalhos das colunas da tabela
            echo "<th>Data Reposição</th>";
            echo "<th>Curso</th>";
            echo "<th>Disciplina</th>";
            echo "<th>Número de Aulas</th>";
            echo "<th>Hora Início Reposição</th>";
            echo "<th>Hora Final Reposição</th>";
            echo "<th>Tipo de Reposição</th>";
            echo "<th>Status Reposição</th>";
            echo "<th>Comentário Coordenação</th>";

            echo "</tr></thead>";
            echo "<tbody>";

            // Exibindo os dados de cada reposição
            foreach ($reposicoes as $reposicao) {
                echo "<tr>";

                // Exibindo os dados de cada reposição
                echo "<td>" . htmlspecialchars($reposicao['datareposicao']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['curso']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['disciplina']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['numeroaulas']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['horainicioreposicao']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['horafinalreposicao']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['tiporeposicao']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['statusreposicao']) . "</td>";
                echo "<td>" . htmlspecialchars($reposicao['comentariocoordenacao'] ?? 'Nenhum comentário') . "</td>";

                echo "</tr>";
            }

            echo "</tbody></table>";
        } else {
            echo "<p>Não há reposições associadas a esta requisição.</p>";
        }
        ?>

        <a href="homepageProfessor.php">
            <button>Voltar</button>
        </a>
    </div>
</body>
</html>
