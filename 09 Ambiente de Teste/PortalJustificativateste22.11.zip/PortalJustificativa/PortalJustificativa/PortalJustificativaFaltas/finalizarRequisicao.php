<?php
session_start();

if (!isset($_SESSION['nome']) || !isset($_SESSION['sobrenome'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=justificativafaltas', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se o ID da requisição foi enviado
    if (isset($_POST['idrequisicao'])) {
        $idRequisicao = (int)$_POST['idrequisicao'];

        // Atualizar o status da requisição
        $sql = "UPDATE tb_requisicao_faltas SET statusrequisicao = 'finalizado' WHERE idrequisicao = :idrequisicao";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idrequisicao', $idRequisicao, PDO::PARAM_INT);
        $stmt->execute();

        echo 'success';
    } else {
        echo 'erro';
    }
} catch (PDOException $e) {
    echo 'Erro ao conectar ao banco de dados: ' . $e->getMessage();
}
?>
