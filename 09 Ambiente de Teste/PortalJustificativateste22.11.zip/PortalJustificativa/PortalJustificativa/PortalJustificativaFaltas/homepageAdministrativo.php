<?php
session_start();

if (!isset($_SESSION['nome']) || !isset($_SESSION['sobrenome'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=justificativafaltas', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Obtendo as requisições, com "aprovado" no topo e "finalizado" no final
    $sql = "SELECT r.idrequisicao, c.siglacurso AS curso, cf.categoria, 
                   DATE_FORMAT(r.data_inicial, '%d %m %Y') AS data_falta, 
                   r.statusrequisicao, r.comentariocoordenacao, p.nome AS professor
            FROM tb_requisicao_faltas r
            JOIN tb_cursos c ON r.idcurso = c.idcurso
            JOIN tb_categoria_faltas cf ON r.idcategoria = cf.idcategoria
            JOIN tb_professores p ON r.idprofessor = p.idprofessor
            ORDER BY 
                CASE WHEN r.statusrequisicao = 'aprovado' THEN 1 
                     WHEN r.statusrequisicao = 'finalizado' THEN 2 
                     ELSE 3 END";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
} catch (PDOException $e) {
    echo "Erro ao conectar ao banco de dados: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Homepage</title>
    <link rel="stylesheet" href="homepageAdm.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400&family=Roboto+Slab:wght@700&display=swap" rel="stylesheet">
    
    <script>
        // Função para filtrar dados da tabela
        function filtrarDados() {
            const filtro = document.getElementById('filtroInput').value.toLowerCase(); // Obtém o valor digitado no campo de filtro
            const linhas = document.querySelectorAll('table tbody tr'); // Obtém todas as linhas da tabela

            // Loop através de todas as linhas da tabela
            linhas.forEach(function(linha) {
                const celulas = linha.querySelectorAll('td'); // Obtém todas as células da linha
                let encontrado = false;

                // Loop para verificar se o filtro corresponde a alguma célula da linha
                celulas.forEach(function(celula) {
                    if (celula.textContent.toLowerCase().includes(filtro)) {
                        encontrado = true; // Se encontrar o filtro na célula, marca como encontrado
                    }
                });

                // Exibe ou oculta a linha com base na correspondência
                if (encontrado) {
                    linha.style.display = ''; // Exibe a linha
                } else {
                    linha.style.display = 'none'; // Oculta a linha
                }
            });
        }

        // Função para finalizar a requisição
        function finalizarRequisicao(idRequisicao, btn) {
            // Criação de um objeto XMLHttpRequest
            const xhr = new XMLHttpRequest();

            // Configura a requisição para o script PHP que processará o status
            xhr.open('POST', 'finalizarRequisicao.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            // Envia a requisição com o ID da requisição
            xhr.send('idrequisicao=' + idRequisicao);

            // Quando a requisição for completada, checa a resposta
            xhr.onload = function () {
                if (xhr.status === 200 && xhr.responseText === 'success') {
                    // Atualiza a célula de status na linha da requisição
                    const linha = btn.closest('tr');
                    const statusCell = linha.querySelector('td:nth-child(5)'); // 5ª célula (coluna de Status)
                    statusCell.textContent = 'Finalizado';

                    // Desabilita o botão de finalizar após a requisição ser finalizada
                    btn.disabled = true;
                    btn.style.cursor = 'not-allowed';
                    btn.innerHTML = ''; // Remover ícone ou texto do botão
                } else {
                    alert('Erro ao finalizar a requisição!');
                }
            };
        }
    </script>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="divA">
                <div class="subDiv1">
                    <h2>PORTAL JUSTIFICATIVA DE FALTAS</h2>
                    <h3>Administrativo</h3>
                </div>
                <div class="subDiv2"> 
                    <img src="img/Logos_oficiais/logo_cps_versao_br.png" alt="Logo">       
                </div>
            </div>
        </div>
    </header>

    <div class="principal">
        <div class="divA1">
            <div class="subA1">
                <?php
                    echo "Bem-vindo(a), " . htmlspecialchars($_SESSION['nome']) . " " . htmlspecialchars($_SESSION['sobrenome']);
                ?>
            </div>
            <div class="subA2">
                <form action="logout.php" method="POST" style="float: right; margin: 10px;">
                    <button type="submit" class="Sairbtn">
                        SAIR
                    </button>
                </form>
            </div>
        </div>

        <div class="divB">
            <div class="subB1">
                <p>Solicitações realizadas</p>
                <input type="text" id="filtroInput" class="inputFiltro" placeholder="Filtrar dados..." onkeyup="filtrarDados()">
            </div>
            <div class="subB2">
                <form>
                    <table>
                        <thead>
                            <tr>
                                <th>Professor</th>
                                <th>Curso</th>
                                <th>Categoria</th>
                                <th>Data da Falta</th>
                                <th>Status</th>
                                <th>Comentário</th>
                                <th>Finalizar</th>
                                <th>Consultar</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            // Loop para exibir as requisições na tabela
                            while ($linha = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($linha['professor']) . "</td>";
                                echo "<td>" . htmlspecialchars($linha['curso']) . "</td>";
                                echo "<td>" . htmlspecialchars($linha['categoria']) . "</td>";
                                echo "<td>" . htmlspecialchars($linha['data_falta']) . "</td>";

                                // Exibir o status (aprovado, finalizado, ou outro)
                                echo "<td>";
                                if ($linha['statusrequisicao'] === 'aprovado') {
                                    echo "Aprovado";
                                } elseif ($linha['statusrequisicao'] === 'finalizado') {
                                    echo "Finalizado";
                                } else {
                                    echo $linha['statusrequisicao']; // Para outros status
                                }
                                echo "</td>";

                                echo "<td>" . htmlspecialchars($linha['comentariocoordenacao'] ?? ' ') . "</td>";

                                // Exibir "FINALIZADO" ou o botão "Finalizar" conforme o status
                                echo "<td>";
                                if ($linha['statusrequisicao'] === 'aprovado') {
                                    echo "<button type='button' onclick='finalizarRequisicao(" . htmlspecialchars($linha['idrequisicao']) . ", this)' style='all: unset; cursor: pointer;' class='btnConsultar'>
                                            <img src='img/Icones/check.svg' alt='Finalizar' class='icon'>
                                          </button>";
                                } elseif ($linha['statusrequisicao'] === 'finalizado') {
                                    echo "";
                                } else {
                                    echo "-";
                                }
                                echo "</td>";

                                // Alteração aqui: mudar o formulário para um link simples
                                echo "<td>
                                        <a href='consultarRequisicaoPronta.php?idrequisicao=" . htmlspecialchars($linha['idrequisicao']) . "&origem=administrativo' style='all: unset; cursor: pointer;' class='btnConsultar'>
                                            <img src='img/Icones/eye2.svg' alt='Consultar' class='icon'>
                                        </a>
                                    </td>";

                                echo "</tr>";
                            }
                        ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
